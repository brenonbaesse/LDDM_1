package com.example.myapplication;

public class Pessoa {
    String nome;
    String email;
    int telefone;

    /*public pessoa(String nome, String email, int telefone){
        this.nome = "";
        this.email = "";
        this.telefone = 0;
    }*/

    public String getNome(){
        return nome;
    }
    public String getEmail(){
        return email;
    }
    public int getTelefone(){
        return telefone;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }
}
